"""Huawei Tech Arena 2026 - V27 Ultra-Fast Dual-Rate (2s + 10s) Strictly Causal Architecture.

Zero future look-ahead and 100% PyTorch-free at inference:
- Bit-for-bit identical 14 (2s) + 71 (10s) features as V26 (reuses v26_dualrate_cache.pkl directly).
- Zero-copy fast paths in BVP finite/bounds masking (~28.6 ms MET).
- Single slim ONNX call runs 5-fold 3-Timescale DualRateGruNet -> optional light causal EMA -> log_bias.
"""
from __future__ import annotations

import bisect
import json
import pathlib
import warnings

import numpy as np
import pandas as pd
import onnxruntime as ort
from scipy import fft as sp_fft
from scipy import signal

from adm_base_class import ADM_Base

CLASSES = np.array(["Rest", "Activity", "Stress"], dtype=object)
WINDOW_S = 10.0
SUB_S = 2.0
SUB_PER_WIN = 5
FS_BVP = 64.0
FS_EDA = 4.0
MAX_GAP_S = 1.0

HR_RANGE = (35.0, 220.0)
IBI_RANGE = (0.27, 2.0)
TEMP_RANGE = (20.0, 42.0)
EDA_MIN = 0.02

SOS_EDA = signal.butter(2, 1.0, btype="lowpass", fs=FS_EDA, output="sos")
SOS_EDA_TONIC = signal.butter(2, 0.05, btype="lowpass", fs=FS_EDA, output="sos")

PULSE_BAND_HZ = (0.6, 3.5)

FEATS_2S = [
    "bvp2_log_rms", "bvp2_mot_4_20", "bvp2_mot_4_8", "bvp2_vhf", "bvp2_diff_rms", "bvp2_mad_ratio",
    "hr2_mean", "hr2_delta_10s", "hr2_delta_60s",
    "eda2_phasic_rms", "eda2_pos_deriv", "eda2_delta_30s", "eda2_delta_120s",
    "temp2_delta_60s",
]

FEATS_10S = [
    # 1. BVP & Physical Motion (17)
    "bvp_log_rms", "bvp_diff_rms", "bvp_mad_ratio", "bvp_pulse_bpm", "bvp_peak_ratio", "bvp_artifact_frac",
    "bvp_periodicity", "bvp_entropy", "bvp_vhf", "bvp_motion_4_20hz", "bvp_motion_4_8hz", "bvp_crest",
    "bvp_lf_hf_ratio", "bvp_motion_60s", "bvp_motion_180s", "motion_max_3m", "motion_max_5m",
    # 2. Heart Rate & Fast 5s Sub-Window Onset (6)
    "hr_mean", "hr_std", "hr_slope", "hr_half_diff", "hr_bvp_pulse_diff", "hr_pulse_ratio",
    # 3. Beat-to-Beat HRV (8)
    "ibi_n", "hrv_rmssd_10s", "hrv_rmssd_60s", "hrv_rmssd_norm_60s", "hrv_sdnn_60s", "hrv_pnn50_60s",
    "hrv_ratio_5m", "hrv_drop_from_peak",
    # 4. Sympathetic EDA & SCR (15)
    "eda_slope", "eda_half_diff", "eda_phasic_ratio", "eda_pos_deriv_norm", "eda_phasic_auc_60s", "eda_phasic_z_5m",
    "log_eda_delta_30s", "log_eda_delta_60s", "log_eda_delta_180s", "eda_z_5m", "log_eda_above_min3m",
    "log_eda_above_q10", "scr_rate_30s", "scr_rate_60s", "scr_amp_60s",
    # 5. Peripheral Vasoconstriction / Skin Temperature Deltas (4)
    "temp_slope", "temp_delta_60s", "temp_delta_180s", "temp_diff_5m",
    # 6. Causal Personal Calibration, Recovery & Acute Stress Separation (17)
    "hr_delta_30s", "hr_delta_60s", "hr_delta_180s", "hr_z_5m", "hr_above_min3m", "hr_trail10m_diff",
    "hr_above_q10", "hr_ratio_q10", "hr_causal_z",
    "hr_max_3m", "hr_drop_from_max3m", "hr_drop_from_max10m", "motion_drop_from_max3m",
    "post_exercise_recovery_idx", "pure_autonomic_stress_idx",
    "bvp_rms_above_q15", "bvp_motion_above_q15",
    # 7. Explicit Sensor Missingness Flags (4 — must remain last 4 channels)
    "hr_missing", "hrv_missing", "eda_missing", "temp_missing",
]

INPUT_COLS = ["BVP", "EDA", "HR", "IBI_dt", "IBI_duration", "Temperature"]


# --------------------------------------------------------------------------------------------
# Fast Unit-Safe Timestamp & Causal Cleaning Helpers (Zero Future Look-Ahead)
# --------------------------------------------------------------------------------------------
_UNIT_TICKS_10S = {"ns": 10_000_000_000, "us": 10_000_000, "ms": 10_000, "s": 10}
_UNIT_SCALE_S = {"ns": 1e-9, "us": 1e-6, "ms": 1e-3, "s": 1.0}


def _index_seconds_aligned(index: pd.DatetimeIndex) -> np.ndarray:
    unit = getattr(index, "unit", None)
    if unit not in _UNIT_SCALE_S:
        unit = np.datetime_data(index.to_numpy().dtype)[0]
    ticks_10s = _UNIT_TICKS_10S.get(unit, 10_000_000_000)
    scale = _UNIT_SCALE_S.get(unit, 1e-9)
    raw = index.asi8
    origin = (raw[0] // ticks_10s) * ticks_10s
    return (raw - origin) * scale


def _segments(t: np.ndarray):
    breaks = np.flatnonzero(np.diff(t) > MAX_GAP_S) + 1
    return zip(np.r_[0, breaks], np.r_[breaks, len(t)])


def _causal_ffill(x: np.ndarray) -> np.ndarray:
    mask = np.isnan(x)
    if not mask.any() or mask.all():
        return x
    idx = np.where(~mask, np.arange(len(x)), 0)
    np.maximum.accumulate(idx, out=idx)
    out = x[idx].copy()
    first_valid = int(np.flatnonzero(~mask)[0])
    if first_valid > 0:
        out[:first_valid] = out[first_valid]
    return out


def _causal_impute_2d(X: np.ndarray, medians: np.ndarray) -> np.ndarray:
    bad = ~np.isfinite(X)
    if not bad.any():
        return X.astype(np.float32, copy=False)
    T, C = X.shape
    idx = np.where(~bad, np.arange(T, dtype=np.int64)[:, None], 0)
    np.maximum.accumulate(idx, axis=0, out=idx)
    out = X[idx, np.arange(C)[None, :]]
    still_bad = ~np.isfinite(out)
    if still_bad.any():
        out = np.where(still_bad, medians[None, :], out)
    return out.astype(np.float32, copy=False)


def _causal_filter_segments(t: np.ndarray, x: np.ndarray, sos) -> np.ndarray:
    out = np.full(len(x), np.nan, dtype=np.float64)
    min_len = 3 * (2 * len(sos) + 1)
    zi_base = signal.sosfilt_zi(sos)
    for s, e in _segments(t):
        seg = x[s:e]
        bad = np.isnan(seg)
        if bad.all():
            continue
        if e - s > min_len:
            filled = _causal_ffill(seg) if bad.any() else seg
            filtered, _ = signal.sosfilt(sos, filled, zi=zi_base * filled[0])
        else:
            filtered = seg.copy()
        if bad.any():
            filtered[bad] = np.nan
        out[s:e] = filtered
    return out


def _reject_outside(x: np.ndarray, lo: float, hi: float) -> np.ndarray:
    out = x.copy()
    out[(out < lo) | (out > hi)] = np.nan
    return out


def _causal_roll_sum(a: np.ndarray, k: int) -> np.ndarray:
    cs = np.r_[0.0, np.cumsum(np.nan_to_num(a, nan=0.0))]
    i = np.arange(len(a))
    s = np.maximum(0, i - k + 1)
    return cs[i + 1] - cs[s]


def _causal_roll_mean(a: np.ndarray, k: int) -> np.ndarray:
    ok = np.isfinite(a)
    cs = np.r_[0.0, np.cumsum(np.where(ok, a, 0.0))]
    cc = np.r_[0.0, np.cumsum(ok.astype(np.float64))]
    i = np.arange(len(a))
    s = np.maximum(0, i - k + 1)
    c = cc[i + 1] - cc[s]
    return np.where(c > 0, (cs[i + 1] - cs[s]) / np.maximum(c, 1.0), np.nan)


def _causal_roll_std(a: np.ndarray, k: int) -> np.ndarray:
    ok = np.isfinite(a)
    v = np.where(ok, a, 0.0)
    cs1 = np.r_[0.0, np.cumsum(v)]
    cs2 = np.r_[0.0, np.cumsum(v * v)]
    cc = np.r_[0.0, np.cumsum(ok.astype(np.float64))]
    i = np.arange(len(a))
    s = np.maximum(0, i - k + 1)
    c = cc[i + 1] - cc[s]
    denom = np.maximum(c, 1.0)
    m = (cs1[i + 1] - cs1[s]) / denom
    var = np.maximum((cs2[i + 1] - cs2[s]) / denom - m * m, 0.0)
    return np.where(c >= 2, np.sqrt(var), np.nan)


def _causal_roll_stat(x: np.ndarray, window: int, mode: str) -> np.ndarray:
    n = len(x)
    if n == 0:
        return x.copy()
    valid = np.isfinite(x)
    if not valid.any():
        return np.full(n, np.nan, dtype=np.float64)
    w = min(window, n)
    filled = _causal_ffill(x) if not valid.all() else x
    padded = np.pad(filled, (w - 1, 0), mode="edge")
    win = np.lib.stride_tricks.sliding_window_view(padded, w)
    if mode == "median":
        if w % 2 == 1:
            res = np.partition(win, w // 2, axis=1)[:, w // 2]
        else:
            res = np.median(win, axis=1)
    elif mode == "max":
        res = win.max(axis=1)
    else:
        res = win.min(axis=1)
    has_valid = _causal_roll_sum(valid.astype(np.float64), w) > 0
    return np.where(has_valid, res, np.nan)


def _causal_reject_spikes(x: np.ndarray, window: int, max_dev: float, relative: bool = False) -> np.ndarray:
    if len(x) < 3 or np.isnan(x).all():
        return x
    med = _causal_roll_stat(x, window, "median")
    dev = np.abs(x - med)
    limit = max_dev * np.abs(med) if relative else max_dev
    out = x.copy()
    out[dev > limit] = np.nan
    return out


def _causal_scr_peaks(et: np.ndarray, ex: np.ndarray, phasic: np.ndarray):
    if len(phasic) <= 4 or not np.isfinite(phasic).any():
        return np.empty(0, dtype=np.float64), np.empty(0, dtype=np.float64)
    ph = np.nan_to_num(phasic, nan=0.0)
    trail_min = _causal_roll_stat(ph, int(3 * FS_EDA), "min")
    rise = np.maximum(ph - np.nan_to_num(trail_min, nan=0.0), 0.0)
    trail_eda = np.nan_to_num(_causal_roll_mean(ex, int(60 * FS_EDA)), nan=0.5)
    min_rise = np.maximum(0.02, 0.005 * trail_eda)

    cand = np.flatnonzero((ph[1:-1] > ph[:-2]) & (ph[1:-1] >= ph[2:]) & (rise[1:-1] >= min_rise[1:-1])) + 2
    if len(cand) == 0:
        return np.empty(0, dtype=np.float64), np.empty(0, dtype=np.float64)

    min_dist = int(FS_EDA)
    kept = [int(cand[0])]
    for idx in cand[1:]:
        if idx - kept[-1] >= min_dist:
            kept.append(int(idx))
    kept_arr = np.asarray(kept, dtype=np.int64)
    return et[kept_arr], rise[kept_arr - 1]


def _causal_damped_quantiles(
    a: np.ndarray, qs: tuple[float, ...], priors: tuple[float, ...], prior_strength: float = 6.0
) -> list[np.ndarray]:
    n = len(a)
    nq = len(qs)
    out = [np.empty(n, dtype=np.float64) for _ in range(nq)]
    sv: list[float] = []
    insort = bisect.insort
    for i in range(n):
        v = a[i]
        if np.isfinite(v):
            insort(sv, float(v))
        m = len(sv)
        if m == 0:
            for qi in range(nq):
                out[qi][i] = priors[qi]
        else:
            w = m / (m + prior_strength)
            one_m_w = 1.0 - w
            m1 = m - 1
            for qi in range(nq):
                pos = qs[qi] * m1
                lo = int(pos)
                hi = lo + 1 if lo < m1 else m1
                val = sv[lo] + (pos - lo) * (sv[hi] - sv[lo])
                out[qi][i] = w * val + one_m_w * priors[qi]
    return out


# --------------------------------------------------------------------------------------------
# Ultra-Fast Zero-Copy Single-Scatter Radix-2 BVP & Window Extractors
# --------------------------------------------------------------------------------------------
def _wid(t: np.ndarray, win_s: float = WINDOW_S) -> np.ndarray:
    return np.floor(t / win_s).astype(np.int64)


def _bin_mean(t: np.ndarray, x: np.ndarray, n: int, win_s: float) -> np.ndarray:
    ok = np.isfinite(x)
    w = _wid(t[ok], win_s)
    keep = (w >= 0) & (w < n)
    w, xv = w[keep], x[ok][keep]
    cnt = np.bincount(w, minlength=n).astype(np.float64)
    return np.where(cnt > 0, np.bincount(w, xv, n) / np.maximum(cnt, 1.0), np.nan)


def _bin_rms(t: np.ndarray, x: np.ndarray, n: int, win_s: float) -> np.ndarray:
    ok = np.isfinite(x)
    w = _wid(t[ok], win_s)
    keep = (w >= 0) & (w < n)
    w, xv = w[keep], x[ok][keep]
    cnt = np.bincount(w, minlength=n).astype(np.float64)
    return np.where(cnt > 0, np.sqrt(np.bincount(w, xv * xv, n) / np.maximum(cnt, 1.0)), np.nan)


def _window_stats(t: np.ndarray, x: np.ndarray, n: int):
    ok = ~np.isnan(x)
    t, x = t[ok], x[ok]
    w = _wid(t, WINDOW_S)
    keep = (w >= 0) & (w < n)
    w, x, t = w[keep], x[keep], t[keep]
    cnt = np.bincount(w, minlength=n).astype(np.float64)
    denom = np.maximum(cnt, 1.0)
    mean = np.where(cnt > 0, np.bincount(w, x, n) / denom, np.nan)
    var = np.where(cnt > 0, np.bincount(w, x * x, n) / denom - np.nan_to_num(mean) ** 2, np.nan)
    t_mean = np.where(cnt > 0, np.bincount(w, t, n) / denom, np.nan)
    cov_tx = np.bincount(w, t * x, n) / denom - np.nan_to_num(t_mean) * np.nan_to_num(mean)
    var_t = np.bincount(w, t * t, n) / denom - np.nan_to_num(t_mean) ** 2
    slope = np.where((cnt >= 3) & (var_t > 1e-9), cov_tx / np.maximum(var_t, 1e-9), np.nan)
    return cnt, mean, np.sqrt(np.maximum(var, 0.0)), slope


def _window_half_diff(t: np.ndarray, x: np.ndarray, n: int) -> np.ndarray:
    ok = np.isfinite(x)
    t, x = t[ok], x[ok]
    w = _wid(t, WINDOW_S)
    keep = (w >= 0) & (w < n)
    w, t, x = w[keep], t[keep], x[keep]
    second = (t - w * WINDOW_S) >= (0.5 * WINDOW_S)
    c1 = np.bincount(w[~second], minlength=n).astype(np.float64)
    c2 = np.bincount(w[second], minlength=n).astype(np.float64)
    s1 = np.bincount(w[~second], weights=x[~second], minlength=n)
    s2 = np.bincount(w[second], weights=x[second], minlength=n)
    valid = (c1 > 0) & (c2 > 0)
    return np.where(valid, s2 / np.maximum(c2, 1.0) - s1 / np.maximum(c1, 1.0), np.nan)


def _window_pos_deriv_rms(t: np.ndarray, x: np.ndarray, n: int, win_s: float = WINDOW_S) -> np.ndarray:
    ok = np.isfinite(x)
    t, x = t[ok], x[ok]
    if len(x) <= 1:
        return np.full(n, np.nan, dtype=np.float64)
    w = _wid(t, win_s)
    dt = np.diff(t)
    dx = np.maximum(np.diff(x), 0.0)
    valid = (dt > 0.0) & (dt <= MAX_GAP_S) & (w[1:] >= 0) & (w[1:] < n)
    if not valid.any():
        return np.full(n, np.nan, dtype=np.float64)
    wd = w[1:][valid]
    pos_sq = (dx[valid] / dt[valid]) ** 2
    dcnt = np.bincount(wd, minlength=n).astype(np.float64)
    dss = np.bincount(wd, weights=pos_sq, minlength=n)
    return np.where(dcnt > 0, np.sqrt(dss / np.maximum(dcnt, 1.0)), np.nan)


_HANN_128 = np.hanning(128).astype(np.float32)
_F128 = np.fft.rfftfreq(128, d=1.0 / FS_BVP)
_P2_PULSE = (_F128 >= 0.5) & (_F128 <= 4.0)
_P2_MOT_4_20 = (_F128 >= 4.0) & (_F128 <= 20.0)
_P2_MOT_4_8 = (_F128 >= 4.0) & (_F128 <= 8.0)
_P2_VHF = _F128 > 8.0
_P2_ALL = _F128 >= 0.5
_PARSEVAL_128 = float(2.0 / (128.0 * float(np.sum(_HANN_128 * _HANN_128))))

_HANN_512 = np.hanning(512).astype(np.float32)
_F512 = np.fft.rfftfreq(512, d=1.0 / FS_BVP)
_P10_PULSE = (_F512 >= PULSE_BAND_HZ[0]) & (_F512 <= PULSE_BAND_HZ[1])
_P10_BPM = _F512[_P10_PULSE] * 60.0
_P10_LF = (_F512 >= 0.6) & (_F512 < 1.5)
_P10_HF = (_F512 >= 1.5) & (_F512 <= 4.0)


def _bvp_dualrate_spectral(bt: np.ndarray, bx: np.ndarray, n: int, n2: int):
    """Zero-copy single-scatter radix-2 float32 spectral extraction at 2s (128-pt) + reused 8s (512-pt)."""
    bx32 = bx.astype(np.float32, copy=False)
    if len(bx32) and (float(bx32.max()) > 1e5 or float(bx32.min()) < -1e5):
        bx32 = np.clip(bx32, -1e5, 1e5)

    w2 = (bt * 0.5).astype(np.int64)
    pos2 = ((bt - w2 * 2.0) * FS_BVP + 0.5).astype(np.int64)
    np.clip(pos2, 0, 127, out=pos2)
    if len(w2) == 0 or (w2[0] >= 0 and w2[-1] < n2):
        wk2, pk2, xk2 = w2, pos2, bx32
    else:
        k2 = (w2 >= 0) & (w2 < n2)
        wk2, pk2, xk2 = w2[k2], pos2[k2], bx32[k2]

    cnt2 = np.bincount(wk2, minlength=n2).astype(np.float32)
    sc2 = np.maximum(cnt2, 1.0)
    m2 = (np.bincount(wk2, weights=xk2, minlength=n2) / sc2).astype(np.float32)

    mat2 = np.zeros((n2, 128), dtype=np.float32)
    mat2[wk2, pk2] = xk2 - m2[wk2]

    cnt10 = cnt2.reshape(n, SUB_PER_WIN)[:, 1:].sum(axis=1)
    sc10 = np.maximum(cnt10, 1.0)
    mat10 = np.ascontiguousarray(mat2.reshape(n, SUB_PER_WIN, 128)[:, 1:, :]).reshape(n, 512)

    rms2_raw = np.sqrt((mat2 * mat2).sum(axis=1) / sc2).astype(np.float64)
    mad2 = (np.abs(mat2).sum(axis=1) / sc2).astype(np.float64)
    bvp2_mad_ratio = mad2 / np.maximum(rms2_raw, 1e-6)
    diff2 = mat2[:, 1:] - mat2[:, :-1]
    bvp2_diff_rms = np.log1p(
        np.sqrt((diff2 * diff2).sum(axis=1, dtype=np.float64) / np.maximum(cnt2.astype(np.float64) - 1.0, 1.0))
    )

    mat2 *= _HANN_128
    f2 = sp_fft.rfft(mat2, axis=1, workers=1)
    p2 = f2.real * f2.real + f2.imag * f2.imag
    pow_pulse2 = p2[:, _P2_PULSE].sum(axis=1, dtype=np.float64)
    pow_all2 = np.maximum(p2[:, _P2_ALL].sum(axis=1, dtype=np.float64), 1e-12)
    safe_p2 = np.maximum(pow_pulse2, 1e-12)

    pulse_rms2 = np.sqrt(np.maximum(pow_pulse2 * _PARSEVAL_128, 0.0))
    bvp2_log_rms = np.log1p(pulse_rms2)
    bvp2_mot_4_20 = np.log((p2[:, _P2_MOT_4_20].sum(axis=1, dtype=np.float64) + 1e-9) / safe_p2)
    bvp2_mot_4_8 = np.log((p2[:, _P2_MOT_4_8].sum(axis=1, dtype=np.float64) + 1e-9) / safe_p2)
    bvp2_vhf = np.log(p2[:, _P2_VHF].sum(axis=1, dtype=np.float64) / pow_all2 + 1e-9)

    empty2 = cnt2 < 64.0
    for a in (pulse_rms2, bvp2_log_rms, bvp2_mot_4_20, bvp2_mot_4_8, bvp2_vhf, bvp2_diff_rms, bvp2_mad_ratio):
        a[empty2] = np.nan

    typical_rms2 = np.nan_to_num(_causal_roll_mean(pulse_rms2, 30), nan=0.0)
    bad2 = empty2 | (pulse_rms2 > 2.5 * typical_rms2) | (pulse_rms2 < 0.25 * typical_rms2)
    bvp_artifact_frac = bad2.reshape(n, SUB_PER_WIN).mean(axis=1).astype(np.float64)

    rms10 = np.sqrt((mat10 * mat10).sum(axis=1) / sc10).astype(np.float64)
    bvp_crest = np.abs(mat10).max(axis=1).astype(np.float64) / np.maximum(rms10, 1e-6)

    mat10 *= _HANN_512
    f10 = sp_fft.rfft(mat10, axis=1, workers=1)
    p10 = f10.real * f10.real + f10.imag * f10.imag
    bp10 = p10[:, _P10_PULSE].astype(np.float64)
    bsum10 = np.maximum(bp10.sum(axis=1), 1e-12)
    bvp_pulse_bpm = _P10_BPM[bp10.argmax(axis=1)]
    bvp_peak_ratio = bp10.max(axis=1) / bsum10
    pn10 = bp10 / bsum10[:, None]
    bvp_entropy = -(pn10 * np.log(pn10 + 1e-12)).sum(axis=1)
    bvp_lf_hf = np.log(
        (p10[:, _P10_LF].sum(axis=1, dtype=np.float64) + 1e-9)
        / (p10[:, _P10_HF].sum(axis=1, dtype=np.float64) + 1e-9)
    )

    p_sub = np.zeros((n, 33), dtype=np.float32)
    p_sub[:, 4:33] = p10[:, 4:33]
    ac = sp_fft.irfft(p_sub, n=64, axis=1, workers=1)
    bvp_periodicity = ac[:, 3:13].max(axis=1).astype(np.float64) / np.maximum(ac[:, 0].astype(np.float64), 1e-12)

    empty10 = cnt10 < 256.0
    for a in (bvp_pulse_bpm, bvp_peak_ratio, bvp_entropy, bvp_lf_hf, bvp_crest, bvp_periodicity):
        a[empty10] = np.nan

    return (
        (bvp2_log_rms, bvp2_mot_4_20, bvp2_mot_4_8, bvp2_vhf, bvp2_diff_rms, bvp2_mad_ratio, empty2),
        (bvp_pulse_bpm, bvp_peak_ratio, bvp_artifact_frac, bvp_periodicity, bvp_entropy, bvp_crest, bvp_lf_hf),
    )


def compute_features(df: pd.DataFrame):
    """Computes strictly causal dual-rate (X_2s: 5*n x 14, X_10s: n x 71) features + row_wid."""
    with warnings.catch_warnings(), np.errstate(all="ignore"):
        warnings.simplefilter("ignore")
        t = _index_seconds_aligned(df.index)
        n = int(t[-1] // WINDOW_S) + 1
        n2 = n * SUB_PER_WIN
        row_wid = _wid(t, WINDOW_S)

        bvp_col = df["BVP"].to_numpy(copy=False)
        b_ok = np.isfinite(bvp_col)
        if b_ok.all():
            bt, bx = t, bvp_col
        else:
            bt, bx = t[b_ok], bvp_col[b_ok]

        def stream64(name: str):
            v = df[name].to_numpy(copy=False)
            keep = np.isfinite(v)
            return t[keep], v[keep].astype(np.float64, copy=False)

        et, ex = stream64("EDA")
        tt, tx = stream64("Temperature")
        ht, hx = stream64("HR")
        ibi_col = df["IBI_duration"].to_numpy(copy=False)
        i_ok = np.isfinite(ibi_col)
        it, ix = t[i_ok], ibi_col[i_ok].astype(np.float64, copy=False)
        ibi_dt = df["IBI_dt"].to_numpy(copy=False)[i_ok].astype(np.float64, copy=False)

        ex = np.where(ex < EDA_MIN, np.nan, ex)
        ex = _causal_reject_spikes(ex, 5, 0.3, relative=True)
        ex = _causal_filter_segments(et, ex, SOS_EDA)
        tonic = _causal_filter_segments(et, ex, SOS_EDA_TONIC)
        phasic = ex - tonic

        tx = _causal_reject_spikes(_reject_outside(tx, *TEMP_RANGE), 9, 0.5)
        hx = _causal_reject_spikes(_reject_outside(hx, *HR_RANGE), 5, 15.0)
        ix_raw = ix
        ix = _causal_reject_spikes(_reject_outside(ix, *IBI_RANGE), 5, 0.25, relative=True)
        consecutive = np.abs(ibi_dt - ix_raw) < 0.05

        scr_t, scr_amp = _causal_scr_peaks(et, ex, phasic)

        (
            (bvp2_log_rms, bvp2_mot_4_20, bvp2_mot_4_8, bvp2_vhf, bvp2_diff_rms, bvp2_mad_ratio, empty2),
            (bvp_pulse_bpm, bvp_peak_ratio, bvp_artifact_frac, bvp_periodicity, bvp_entropy, bvp_crest, bvp_lf_hf),
        ) = _bvp_dualrate_spectral(bt, bx, n, n2)

        hr2_mean = _bin_mean(ht, hx, n2, SUB_S)
        hr2_delta_10s = hr2_mean - _causal_roll_mean(hr2_mean, 5)
        hr2_delta_60s = hr2_mean - _causal_roll_mean(hr2_mean, 30)

        eda2_tonic_raw = _bin_mean(et, tonic, n2, SUB_S)
        log_eda2 = np.log1p(np.maximum(eda2_tonic_raw, 0.0))
        denom_e2 = np.maximum(eda2_tonic_raw, 0.0) + 0.05
        eda2_phasic_rms = _bin_rms(et, phasic, n2, SUB_S) / denom_e2
        eda2_pos_deriv = _window_pos_deriv_rms(et, phasic, n2, SUB_S) / denom_e2
        eda2_delta_30s = log_eda2 - _causal_roll_mean(log_eda2, 15)
        eda2_delta_120s = log_eda2 - _causal_roll_mean(log_eda2, 60)

        temp2_mean = _bin_mean(tt, tx, n2, SUB_S)
        temp2_delta_60s = temp2_mean - _causal_roll_mean(temp2_mean, 30)

        X_2s = np.column_stack(
            [
                bvp2_log_rms, bvp2_mot_4_20, bvp2_mot_4_8, bvp2_vhf, bvp2_diff_rms, bvp2_mad_ratio,
                hr2_mean, hr2_delta_10s, hr2_delta_60s,
                eda2_phasic_rms, eda2_pos_deriv, eda2_delta_30s, eda2_delta_120s,
                temp2_delta_60s,
            ]
        ).astype(np.float32)
        X_2s[~np.isfinite(X_2s)] = np.nan

        ok2 = (~empty2).reshape(n, SUB_PER_WIN)
        c5 = ok2.sum(axis=1)
        has5 = c5 > 0
        inv_c5 = 1.0 / np.maximum(c5, 1)

        def agg5(arr: np.ndarray) -> np.ndarray:
            r = arr.reshape(n, SUB_PER_WIN)
            return np.where(has5, np.where(ok2, r, 0.0).sum(axis=1) * inv_c5, np.nan)

        f = {}
        f["bvp_log_rms"] = agg5(bvp2_log_rms)
        f["bvp_diff_rms"] = agg5(bvp2_diff_rms)
        f["bvp_mad_ratio"] = agg5(bvp2_mad_ratio)
        f["bvp_motion_4_20hz"] = agg5(bvp2_mot_4_20)
        f["bvp_motion_4_8hz"] = agg5(bvp2_mot_4_8)
        f["bvp_vhf"] = agg5(bvp2_vhf)
        f["bvp_pulse_bpm"] = bvp_pulse_bpm
        f["bvp_peak_ratio"] = bvp_peak_ratio
        f["bvp_artifact_frac"] = bvp_artifact_frac
        f["bvp_periodicity"] = bvp_periodicity
        f["bvp_entropy"] = bvp_entropy
        f["bvp_crest"] = bvp_crest
        f["bvp_lf_hf_ratio"] = bvp_lf_hf

        f["bvp_motion_60s"] = _causal_roll_mean(f["bvp_motion_4_20hz"], 6)
        f["bvp_motion_180s"] = _causal_roll_mean(f["bvp_motion_4_20hz"], 18)
        f["motion_max_3m"] = _causal_roll_stat(f["bvp_motion_4_20hz"], 18, "max")
        f["motion_max_5m"] = _causal_roll_stat(f["bvp_motion_4_20hz"], 30, "max")

        _, f["hr_mean"], f["hr_std"], f["hr_slope"] = _window_stats(ht, hx, n)
        f["hr_half_diff"] = _window_half_diff(ht, hx, n)
        f["hr_bvp_pulse_diff"] = np.abs(f["hr_mean"] - f["bvp_pulse_bpm"])
        f["hr_pulse_ratio"] = f["hr_mean"] / np.maximum(f["bvp_pulse_bpm"], 35.0)

        ok = np.isfinite(ix)
        w_all = _wid(it, WINDOW_S)
        keep = ok & (w_all >= 0) & (w_all < n)
        w = w_all[keep]
        cnt = np.bincount(w, minlength=n).astype(np.float64)
        s1 = np.bincount(w, ix[keep], minlength=n)
        s2 = np.bincount(w, ix[keep] ** 2, minlength=n)
        diff = np.diff(ix, prepend=np.nan)
        pair = keep & consecutive & np.isfinite(diff)
        wd = w_all[pair]
        d_cnt = np.bincount(wd, minlength=n).astype(np.float64)
        d_ss = np.bincount(wd, diff[pair] ** 2, minlength=n)
        nn50 = np.bincount(wd, weights=(np.abs(diff[pair]) > 0.05).astype(np.float64), minlength=n)

        f["ibi_n"] = cnt
        f["hrv_rmssd_10s"] = np.where(d_cnt >= 2, np.sqrt(d_ss / np.maximum(d_cnt, 1.0)), np.nan) * 1000.0
        c60 = _causal_roll_sum(cnt, 6)
        s60 = _causal_roll_sum(s1, 6)
        s260 = _causal_roll_sum(s2, 6)
        dc60 = _causal_roll_sum(d_cnt, 6)
        dss60 = _causal_roll_sum(d_ss, 6)
        ibi_mean_60s = np.where(c60 >= 5, s60 / np.maximum(c60, 1.0), np.nan)
        rmssd_60s_s = np.where(dc60 >= 5, np.sqrt(dss60 / np.maximum(dc60, 1.0)), np.nan)
        f["hrv_rmssd_60s"] = rmssd_60s_s * 1000.0
        f["hrv_rmssd_norm_60s"] = rmssd_60s_s / np.maximum(ibi_mean_60s, 0.25)
        f["hrv_sdnn_60s"] = (
            np.where(
                c60 >= 5,
                np.sqrt(np.maximum(s260 / np.maximum(c60, 1.0) - (s60 / np.maximum(c60, 1.0)) ** 2, 0.0)),
                np.nan,
            )
            * 1000.0
        )
        f["hrv_pnn50_60s"] = np.where(dc60 >= 5, _causal_roll_sum(nn50, 6) / np.maximum(dc60, 1.0), np.nan)
        f["hrv_ratio_5m"] = f["hrv_rmssd_60s"] / np.maximum(_causal_roll_mean(f["hrv_rmssd_60s"], 30), 10.0)

        _, _, _, f["eda_slope"] = _window_stats(et, ex, n)
        _, eda_tonic_raw, _, _ = _window_stats(et, tonic, n)
        log_eda_tonic = np.log1p(np.maximum(eda_tonic_raw, 0.0))
        f["eda_half_diff"] = _window_half_diff(et, np.log1p(np.maximum(ex, 0.0)), n)
        _, _, eda_phasic_std, _ = _window_stats(et, phasic, n)
        eda_pos_deriv = _window_pos_deriv_rms(et, phasic, n, WINDOW_S)
        _, eda_phasic_pos, _, _ = _window_stats(et, np.maximum(phasic, 0.0), n)
        _, temp_mean, _, f["temp_slope"] = _window_stats(tt, tx, n)

        denom_eda = np.maximum(eda_tonic_raw, 0.0) + 0.05
        f["eda_phasic_ratio"] = eda_phasic_std / denom_eda
        f["eda_pos_deriv_norm"] = eda_pos_deriv / denom_eda
        f["eda_phasic_auc_60s"] = _causal_roll_mean(eda_phasic_pos, 6)

        ep_m5 = _causal_roll_mean(eda_phasic_std, 30)
        ep_s5 = _causal_roll_std(eda_phasic_std, 30)
        f["eda_phasic_z_5m"] = (eda_phasic_std - ep_m5) / np.maximum(ep_s5, 0.01)

        f["log_eda_delta_30s"] = log_eda_tonic - _causal_roll_mean(log_eda_tonic, 3)
        f["log_eda_delta_60s"] = log_eda_tonic - _causal_roll_mean(log_eda_tonic, 6)
        f["log_eda_delta_180s"] = log_eda_tonic - _causal_roll_mean(log_eda_tonic, 18)
        f["log_eda_above_min3m"] = log_eda_tonic - _causal_roll_stat(log_eda_tonic, 18, "min")
        eda_m5 = _causal_roll_mean(log_eda_tonic, 30)
        eda_s5 = _causal_roll_std(log_eda_tonic, 30)
        f["eda_z_5m"] = (log_eda_tonic - eda_m5) / np.maximum(eda_s5, 0.03)

        scr_w = _wid(scr_t, WINDOW_S)
        scr_valid = (scr_w >= 0) & (scr_w < n)
        scr = np.bincount(scr_w[scr_valid], minlength=n)[:n].astype(np.float64)
        scr_a = np.bincount(scr_w[scr_valid], weights=scr_amp[scr_valid], minlength=n)[:n]
        f["scr_rate_30s"] = _causal_roll_sum(scr, 3)
        f["scr_rate_60s"] = _causal_roll_sum(scr, 6)
        f["scr_amp_60s"] = _causal_roll_sum(scr_a, 6)

        f["temp_delta_60s"] = temp_mean - _causal_roll_mean(temp_mean, 6)
        f["temp_delta_180s"] = temp_mean - _causal_roll_mean(temp_mean, 18)
        f["temp_diff_5m"] = temp_mean - _causal_roll_mean(temp_mean, 30)

        f["hr_delta_30s"] = f["hr_mean"] - _causal_roll_mean(f["hr_mean"], 3)
        f["hr_delta_60s"] = f["hr_mean"] - _causal_roll_mean(f["hr_mean"], 6)
        f["hr_delta_180s"] = f["hr_mean"] - _causal_roll_mean(f["hr_mean"], 18)
        f["hr_above_min3m"] = f["hr_mean"] - _causal_roll_stat(f["hr_mean"], 18, "min")
        f["hr_trail10m_diff"] = f["hr_mean"] - _causal_roll_mean(f["hr_mean"], 60)
        hr_m5 = _causal_roll_mean(f["hr_mean"], 30)
        hr_s5 = _causal_roll_std(f["hr_mean"], 30)
        f["hr_z_5m"] = (f["hr_mean"] - hr_m5) / np.maximum(hr_s5, 3.0)

        f["hr_max_3m"] = _causal_roll_stat(f["hr_mean"], 18, "max")
        f["hr_drop_from_max3m"] = f["hr_max_3m"] - f["hr_mean"]
        f["hr_drop_from_max10m"] = _causal_roll_stat(f["hr_mean"], 60, "max") - f["hr_mean"]
        f["motion_drop_from_max3m"] = f["motion_max_3m"] - f["bvp_motion_4_20hz"]

        vhf_max_10m = _causal_roll_stat(f["bvp_vhf"], 60, "max")
        vhf_drop_10m = vhf_max_10m - f["bvp_vhf"]
        f["post_exercise_recovery_idx"] = np.maximum(f["hr_drop_from_max10m"], 0.0) * np.maximum(vhf_drop_10m, 0.0)
        f["pure_autonomic_stress_idx"] = (
            np.maximum(f["hr_delta_180s"], 0.0)
            + 20.0 * np.maximum(f["log_eda_delta_180s"], 0.0)
            - 10.0 * np.maximum(vhf_max_10m + 3.5, 0.0)
        )

        hr_q10, hr_q50, hr_q85 = _causal_damped_quantiles(f["hr_mean"], (0.10, 0.50, 0.85), (64.0, 74.0, 105.0), 6.0)
        (eda_q10,) = _causal_damped_quantiles(log_eda_tonic, (0.10,), (0.25,), 6.0)
        (bvp_q15,) = _causal_damped_quantiles(f["bvp_log_rms"], (0.15,), (2.5,), 6.0)
        (mot_q15,) = _causal_damped_quantiles(f["bvp_motion_4_20hz"], (0.15,), (-2.5,), 6.0)
        (hrv_q85,) = _causal_damped_quantiles(f["hrv_rmssd_60s"], (0.85,), (55.0,), 6.0)

        f["hr_above_q10"] = f["hr_mean"] - hr_q10
        f["hr_ratio_q10"] = f["hr_mean"] / np.maximum(hr_q10, 40.0)
        f["hr_causal_z"] = (f["hr_mean"] - hr_q50) / np.maximum(hr_q85 - hr_q10, 8.0)
        f["log_eda_above_q10"] = log_eda_tonic - eda_q10
        f["bvp_rms_above_q15"] = f["bvp_log_rms"] - bvp_q15
        f["bvp_motion_above_q15"] = f["bvp_motion_4_20hz"] - mot_q15
        f["hrv_drop_from_peak"] = hrv_q85 - f["hrv_rmssd_60s"]

        f["hr_missing"] = (~np.isfinite(f["hr_mean"])).astype(np.float64)
        f["hrv_missing"] = (~np.isfinite(f["hrv_rmssd_60s"])).astype(np.float64)
        f["eda_missing"] = (~np.isfinite(eda_tonic_raw)).astype(np.float64)
        f["temp_missing"] = (~np.isfinite(temp_mean)).astype(np.float64)

        X_10s = np.column_stack([f[k] for k in FEATS_10S]).astype(np.float32)
        X_10s[~np.isfinite(X_10s)] = np.nan
        return X_2s, X_10s, row_wid


def causal_ema_probs(P: np.ndarray, alpha: float) -> np.ndarray:
    if alpha >= 0.999 or len(P) < 2:
        return P
    out = np.empty_like(P, dtype=np.float64)
    out[0] = P[0]
    one_minus = 1.0 - alpha
    for i in range(1, len(P)):
        out[i] = alpha * P[i] + one_minus * out[i - 1]
    return out


class YourModel(ADM_Base):
    def load_model(self, onnx_file: pathlib.Path) -> None:
        so = ort.SessionOptions()
        so.intra_op_num_threads = 1
        so.inter_op_num_threads = 1
        so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        self.session = ort.InferenceSession(str(onnx_file), sess_options=so, providers=["CPUExecutionProvider"])
        meta = json.loads(self.session.get_modelmeta().custom_metadata_map["eh_config"])

        ins = [i.name for i in self.session.get_inputs()]
        outs = [o.name for o in self.session.get_outputs()]
        self.nn_x2_in = next(n for n in ins if "x2" in n)
        self.nn_x10_in = next(n for n in ins if "x10" in n)
        self.nn_out = outs[0]

        self.cols_2s = np.array([FEATS_2S.index(c) for c in meta["feats_2s"]], dtype=np.int64)
        self.cols_10s = np.array([FEATS_10S.index(c) for c in meta["feats_10s"]], dtype=np.int64)
        self.med_2s = np.asarray(meta["med_2s"], dtype=np.float32)
        self.med_10s = np.asarray(meta["med_10s"], dtype=np.float32)
        self.ema_alpha = float(meta.get("ema_alpha", 1.0))
        self.log_bias = np.asarray(meta.get("log_bias", [0.0, 0.0, 0.0]), dtype=np.float64)

    def predict_windows(self, df: pd.DataFrame):
        X_2s, X_10s, row_wid = compute_features(df)
        X2_in = np.ascontiguousarray(
            _causal_impute_2d(X_2s[:, self.cols_2s], self.med_2s)[None, :, :], dtype=np.float32
        )
        X10_sub = X_10s[:, self.cols_10s]
        X10_in = np.ascontiguousarray(
            np.where(np.isfinite(X10_sub), X10_sub, self.med_10s)[None, :, :], dtype=np.float32
        )
        P = np.asarray(
            self.session.run([self.nn_out], {self.nn_x2_in: X2_in, self.nn_x10_in: X10_in})[0][0],
            dtype=np.float64,
        )
        if self.ema_alpha < 0.999:
            P = causal_ema_probs(P, self.ema_alpha)
        score = np.log(np.maximum(P, 1e-9)) + self.log_bias
        return score.argmax(axis=1), row_wid

    def run(self, input: pd.DataFrame) -> pd.DataFrame:
        n_rows = len(input)
        if n_rows == 0:
            return pd.DataFrame({"Activity": pd.Series(dtype=object)}, index=input.index)
        data = input
        if not isinstance(data.index, pd.DatetimeIndex):
            data = data[INPUT_COLS].set_axis(pd.date_range("2000-01-01", periods=n_rows, freq="15625us"))
        segs = _input_segments(data.index)
        cls = np.zeros(n_rows, dtype=np.int8)
        with warnings.catch_warnings(), np.errstate(all="ignore"):
            warnings.simplefilter("ignore")
            for s, e in segs:
                try:
                    chunk = data if (s == 0 and e == n_rows) else data.iloc[s:e]
                    win_pred, row_wid = self.predict_windows(chunk)
                    cls[s:e] = win_pred[np.clip(row_wid, 0, len(win_pred) - 1)]
                except Exception:
                    self.fallbacks = getattr(self, "fallbacks", 0) + 1
        return pd.DataFrame(CLASSES[cls], index=input.index, columns=["Activity"], dtype=object, copy=False)


MAX_JUMP_S = 300.0


def _input_segments(index: pd.DatetimeIndex) -> list[tuple[int, int]]:
    t_sec = _index_seconds_aligned(index)
    d = np.diff(t_sec)
    breaks = np.flatnonzero((d < 0.0) | (d > MAX_JUMP_S)) + 1
    if len(breaks) == 0:
        return [(0, len(t_sec))]
    return list(zip(np.r_[0, breaks], np.r_[breaks, len(t_sec)]))


def get_model() -> ADM_Base:
    model = YourModel()
    model.load_model(pathlib.Path(__file__).with_suffix(".onnx"))
    return model