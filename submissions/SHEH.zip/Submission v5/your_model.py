"""Huawei Tech Arena 2026 - activity detection (Rest / Activity / Stress) from wristband signals."""
from __future__ import annotations

import json
import pathlib
import warnings

import numpy as np
import pandas as pd
import onnxruntime as ort
from scipy import signal

from adm_base_class import ADM_Base

CLASSES = np.array(["Rest", "Activity", "Stress"], dtype=object)
WINDOW_S = 10.0
FS_BVP = 64.0
FS_EDA = 4.0
MAX_GAP_S = 1.0

HR_RANGE = (35.0, 220.0)
IBI_RANGE = (0.27, 2.0)
TEMP_RANGE = (20.0, 42.0)
EDA_MIN = 0.02

SOS_BVP = signal.butter(2, [0.5, 4.0], btype="bandpass", fs=FS_BVP, output="sos")
SOS_EDA = signal.butter(2, 1.0, btype="lowpass", fs=FS_EDA, output="sos")
SOS_EDA_TONIC = signal.butter(2, 0.05, btype="lowpass", fs=FS_EDA, output="sos")

CONTEXT_WINDOWS = 6     # 60 s centred context
LOCAL_WINDOWS = 30      # 5-minute local baseline
PULSE_BAND_HZ = (0.6, 3.5)

WINDOW_FEATURES = [
    "bvp_log_rms", "bvp_pulse_bpm", "bvp_peak_ratio", "bvp_artifact_frac",
    "bvp_raw_log_std", "bvp_hf_log_power", "bvp_hf_ratio", "bvp_jerk_log_rms",
    "hr_mean", "hr_std", "hr_slope", "hr_per_bvp_hf",
    "ibi_mean", "ibi_n",
    "eda_mean", "eda_slope", "eda_tonic", "eda_phasic_std",
    "temp_mean",
    "eda_phasic_ratio", "scr_per_hr", "hr_temp_div",
    "hr_above_floor", "eda_above_floor", "bvp_rms_above_floor", "hrv_drop_from_peak",
    "hr_range_norm", "eda_range_norm", "eda_rel_slope", "hr_motion_gap",
    "scr_above_floor", "phasic_above_floor", "temp_below_ceiling",
    "stress_autonomic_idx", "still_arousal_idx",
    "hr_recovery_2m", "bvp_recovery_2m", "eda_recovery_2m",
    "hr_bvp_ratio", "pulse_hr_diff",
    "hr_delta_10s", "hr_delta_30s", "bvp_rms_delta_10s", "bvp_rms_delta_30s",
    "phasic_delta_20s", "eda_slope_fast", "stress_burst_idx", "cooldown_idx",
]
CONTEXT_FEATURES = ["hrv_rmssd_60s", "hrv_sdnn_60s", "scr_rate_60s", "temp_slope_60s", "eda_slope_60s",
                    "hr_mean_60s"]
RELATIVE_BASES = ["hr_mean", "bvp_pulse_bpm", "eda_tonic", "temp_mean", "bvp_log_rms", "ibi_mean",
                  "scr_rate_60s", "hrv_rmssd_60s"]
RELATIVE_FEATURES = ([f"{b}_rel" for b in RELATIVE_BASES] + [f"{b}_z" for b in RELATIVE_BASES]
                     + [f"{b}_local" for b in RELATIVE_BASES])
LONG_BASES = ["hr_mean", "bvp_log_rms", "bvp_artifact_frac", "eda_tonic", "scr_rate_60s"]
LONG_FEATURES = [f"{b}_{w}m" for b in LONG_BASES for w in (2, 5)]
REC_BASES = ["hr_mean", "bvp_artifact_frac", "bvp_log_rms", "bvp_hf_log_power", "eda_tonic", "scr_rate_60s", "temp_mean"]
REC_FEATURES = [f"rec_{b}_q{q}" for b in REC_BASES for q in (10, 50, 90)] + ["rec_hr_range", "rec_dur"]
TIME_FEATURES = ["t_s", "t_frac", "t_left"]
LAG_BASES = ["hr_mean_local", "eda_tonic_local", "bvp_log_rms_local", "scr_rate_60s", "hrv_rmssd_60s_local",
             "temp_slope_60s", "bvp_artifact_frac", "hr_mean_rel"]
LAGS = (-18, -12, -6, -3, 3, 6, 12, 18)
LAG_FEATURES = [f"{b}_lag{L}" for L in LAGS for b in LAG_BASES]
ALL_FEATURES = (WINDOW_FEATURES + CONTEXT_FEATURES + RELATIVE_FEATURES + LONG_FEATURES
                + REC_FEATURES + TIME_FEATURES + LAG_FEATURES)
INPUT_COLS = ["BVP", "EDA", "HR", "IBI_dt", "IBI_duration", "Temperature"]


def _segments(t: np.ndarray):
    breaks = np.flatnonzero(np.diff(t) > MAX_GAP_S) + 1
    return zip(np.r_[0, breaks], np.r_[breaks, len(t)])


def _interp_nan(x: np.ndarray) -> np.ndarray:
    bad = np.isnan(x)
    if not bad.any() or bad.all():
        return x
    x = x.copy()
    idx = np.arange(len(x))
    x[bad] = np.interp(idx[bad], idx[~bad], x[~bad])
    return x


def _filtfilt_segments(t, x, sos, drop_short: bool, one_pass: bool = False) -> np.ndarray:
    out = np.full(len(x), np.nan)
    padlen = 3 * (2 * len(sos) + 1)
    for s, e in _segments(t):
        seg = x[s:e]
        bad = np.isnan(seg)
        if bad.all():
            continue
        if e - s > padlen:
            filtered = (signal.sosfilt(sos, _interp_nan(seg)) if one_pass
                        else signal.sosfiltfilt(sos, _interp_nan(seg)))
        elif drop_short:
            continue
        else:
            filtered = seg.copy()
        filtered[bad] = np.nan
        out[s:e] = filtered
    return out


def _reject_outside(x, lo, hi):
    x = x.copy()
    x[(x < lo) | (x > hi)] = np.nan
    return x


def _reject_spikes(x, kernel, max_dev, relative=False):
    if len(x) < kernel or np.isnan(x).all():
        return x
    med = signal.medfilt(_interp_nan(x), kernel)
    dev = np.abs(x - med)
    limit = max_dev * np.abs(med) if relative else max_dev
    x = x.copy()
    x[dev > limit] = np.nan
    return x


def _bvp_artifacts(t, x) -> np.ndarray:
    if len(t) == 0:
        return np.zeros(0, dtype=bool)
    block = np.floor(t).astype(np.int64)
    valid = ~np.isnan(x)
    n = int(block[-1]) + 1
    cnt = np.bincount(block[valid], minlength=n)
    ss = np.bincount(block[valid], weights=x[valid] ** 2, minlength=n)
    rms = np.sqrt(ss / np.maximum(cnt, 1))
    typical = np.median(rms[cnt > 0]) if (cnt > 0).any() else 0.0
    bad_block = (cnt == 0) | (rms > 2.5 * typical) | (rms < 0.25 * typical)
    return bad_block[block] | ~valid


def _wid(t):
    return np.floor(t / WINDOW_S).astype(np.int64)


def _window_stats(t, x, n):
    ok = ~np.isnan(x)
    t, x = t[ok], x[ok]
    w = _wid(t)
    keep = (w >= 0) & (w < n)
    w, x, t = w[keep], x[keep], t[keep]
    cnt = np.bincount(w, minlength=n).astype(np.float64)
    safe_cnt = np.maximum(cnt, 1.0)
    has_data = cnt > 0
    mean = np.where(has_data, np.bincount(w, x, minlength=n) / safe_cnt, np.nan)
    var = np.where(has_data, np.bincount(w, x * x, minlength=n) / safe_cnt - np.nan_to_num(mean) ** 2, np.nan)
    t_mean = np.where(has_data, np.bincount(w, t, minlength=n) / safe_cnt, 0.0)
    cov_tx = np.where(has_data, np.bincount(w, t * x, minlength=n) / safe_cnt - t_mean * np.nan_to_num(mean), np.nan)
    var_t = np.where(has_data, np.bincount(w, t * t, minlength=n) / safe_cnt - t_mean ** 2, 0.0)
    slope = np.where((cnt >= 3) & (var_t > 0), cov_tx / np.where(var_t > 0, var_t, 1.0), np.nan)
    return cnt, mean, np.sqrt(np.maximum(var, 0.0)), slope


def _bvp_spectral(t, x, n):
    per_win = int(WINDOW_S * FS_BVP)
    ok = ~np.isnan(x)
    w = _wid(t[ok])
    pos = np.clip(np.round((t[ok] - w * WINDOW_S) * FS_BVP).astype(np.int64), 0, per_win - 1)
    keep = (w >= 0) & (w < n)
    mat = np.zeros((n, per_win))
    mat[w[keep], pos[keep]] = x[ok][keep]
    cnt = np.bincount(w[keep], minlength=n)
    power = np.abs(np.fft.rfft(mat * np.hanning(per_win), axis=1)) ** 2
    freqs = np.fft.rfftfreq(per_win, d=1.0 / FS_BVP)
    band = (freqs >= PULSE_BAND_HZ[0]) & (freqs <= PULSE_BAND_HZ[1])
    band_power = power[:, band]
    band_sum = band_power.sum(axis=1)
    pulse_bpm = freqs[band][band_power.argmax(axis=1)] * 60.0
    peak_ratio = np.where(band_sum > 0, band_power.max(axis=1) / np.maximum(band_sum, 1e-12), np.nan)
    log_rms = np.log1p(np.sqrt((mat ** 2).sum(axis=1) / np.maximum(cnt, 1)))
    empty = cnt < per_win // 2
    for a in (pulse_bpm, peak_ratio, log_rms):
        a[empty] = np.nan
    return pulse_bpm, peak_ratio, log_rms


def _same(a, k):
    full = np.convolve(a, np.ones(k), mode="full")
    start = (k - 1) // 2
    return full[start:start + len(a)]


def _roll_sum(a, k):
    return _same(a, k)


def _nan_roll_mean(a, k):
    ok = np.isfinite(a)
    s = _same(np.where(ok, a, 0.0), k)
    c = _same(ok.astype(np.float64), k)
    return np.where(c > 0, s / np.maximum(c, 1), np.nan)


def _nan_roll_median(a: np.ndarray, k: int) -> np.ndarray:
    return pd.Series(a).rolling(k, center=True, min_periods=3).median().to_numpy()


def _relative(a):
    nan = np.full(len(a), np.nan)
    v = a[np.isfinite(a)]
    if len(v) < 2:
        return nan, nan, nan
    q25, med, q75 = np.percentile(v, [25, 50, 75])
    spread = q75 - q25
    z = (a - med) / spread if spread > 0 else nan
    local = a - _nan_roll_median(a, LOCAL_WINDOWS)
    return a - med, z, local


def _qs(a, qs):
    v = a[np.isfinite(a)]
    return np.percentile(v, qs) if len(v) else np.full(len(qs), np.nan)


def compute_features(df: pd.DataFrame):
    idx = df.index
    origin = idx[0].floor("10s")
    t = np.asarray((idx - origin).total_seconds(), dtype=np.float64)
    offset = t[0]
    n = int(t[-1] // WINDOW_S) + 1
    row_wid = _wid(t)

    col = {c: df[c].to_numpy(dtype=np.float64) for c in INPUT_COLS}

    def stream(name):
        keep = np.isfinite(col[name])
        return t[keep], col[name][keep]

    bt, bx = stream("BVP")
    et, ex = stream("EDA")
    tt, tx = stream("Temperature")
    ht, hx = stream("HR")
    it, ix = stream("IBI_duration")
    ibi_dt = col["IBI_dt"][np.isfinite(col["IBI_duration"])]

    bx = np.clip(bx, -1e5, 1e5)
    bx_raw = bx.copy()
    bx = _filtfilt_segments(bt, bx, SOS_BVP, drop_short=True, one_pass=True)
    bvp_art = _bvp_artifacts(bt, bx)
    ex = np.where(ex < EDA_MIN, np.nan, ex)
    ex = _reject_spikes(ex, 5, 0.3, relative=True)
    ex = _filtfilt_segments(et, ex, SOS_EDA, drop_short=False)
    tonic = _filtfilt_segments(et, ex, SOS_EDA_TONIC, drop_short=False)
    phasic = ex - tonic
    tx = _reject_spikes(_reject_outside(tx, *TEMP_RANGE), 9, 0.5)
    hx = _reject_spikes(_reject_outside(hx, *HR_RANGE), 5, 15.0)
    ix_raw = ix
    ix = _reject_spikes(_reject_outside(ix, *IBI_RANGE), 5, 0.25, relative=True)
    consecutive = np.abs(ibi_dt - ix_raw) < 0.05

    scr_t = np.empty(0)
    if len(phasic) > 4 and np.isfinite(phasic).any():
        min_rise = max(0.02, 0.005 * float(np.nanmedian(ex)))
        peaks, _ = signal.find_peaks(np.nan_to_num(phasic), prominence=min_rise, distance=int(FS_EDA))
        scr_t = et[peaks]

    f = {}
    f["bvp_pulse_bpm"], f["bvp_peak_ratio"], f["bvp_log_rms"] = _bvp_spectral(bt, bx, n)

    # Raw BVP high-frequency (4-20 Hz) wrist motion features
    per_win = int(WINDOW_S * FS_BVP)
    ok_raw = np.isfinite(bx_raw)
    w_raw = _wid(bt[ok_raw])
    pos_raw = np.clip(np.round((bt[ok_raw] - w_raw * WINDOW_S) * FS_BVP).astype(np.int64), 0, per_win - 1)
    keep_raw = (w_raw >= 0) & (w_raw < n)
    mat_raw = np.zeros((n, per_win))
    mat_raw[w_raw[keep_raw], pos_raw[keep_raw]] = bx_raw[ok_raw][keep_raw]
    cnt_raw = np.bincount(w_raw[keep_raw], minlength=n)
    empty_raw = cnt_raw < per_win // 2

    raw_std = np.std(mat_raw, axis=1)
    jerk_rms = np.sqrt(np.mean(np.diff(mat_raw, axis=1) ** 2, axis=1))
    power_raw = np.abs(np.fft.rfft(mat_raw * np.hanning(per_win), axis=1)) ** 2
    freqs_raw = np.fft.rfftfreq(per_win, d=1.0 / FS_BVP)
    cardiac_band = (freqs_raw >= 0.6) & (freqs_raw <= 3.5)
    hf_band = (freqs_raw > 4.0) & (freqs_raw <= 20.0)
    hf_pow = power_raw[:, hf_band].sum(axis=1)
    tot_pow = np.maximum(power_raw[:, cardiac_band].sum(axis=1) + hf_pow, 1e-12)

    bvp_raw_log_std = np.log1p(raw_std)
    bvp_hf_log_power = np.log1p(np.sqrt(hf_pow / per_win))
    bvp_hf_ratio = hf_pow / tot_pow
    bvp_jerk_log_rms = np.log1p(jerk_rms)
    for arr in (bvp_raw_log_std, bvp_hf_log_power, bvp_hf_ratio, bvp_jerk_log_rms):
        arr[empty_raw] = np.nan

    f["bvp_raw_log_std"] = bvp_raw_log_std
    f["bvp_hf_log_power"] = bvp_hf_log_power
    f["bvp_hf_ratio"] = bvp_hf_ratio
    f["bvp_jerk_log_rms"] = bvp_jerk_log_rms

    aw = _wid(bt).astype(np.int64)
    keep_bvp = (aw >= 0) & (aw < n)
    aw_k = aw[keep_bvp]
    f["bvp_artifact_frac"] = (
        np.bincount(aw_k, bvp_art[keep_bvp].astype(np.float64), minlength=n)[:n]
        / np.maximum(np.bincount(aw_k, minlength=n)[:n], 1)
    )
    _, f["hr_mean"], f["hr_std"], f["hr_slope"] = _window_stats(ht, hx, n)
    f["hr_per_bvp_hf"] = f["hr_mean"] / (f["bvp_hf_log_power"] + 0.5)

    ok = np.isfinite(ix)
    w_all = _wid(it).astype(np.int64)
    keep = ok & (w_all >= 0) & (w_all < n)
    w = w_all[keep]
    cnt = np.bincount(w, minlength=n).astype(np.float64)
    safe_cnt = np.maximum(cnt, 1.0)
    s1 = np.bincount(w, ix[keep], minlength=n)
    s2 = np.bincount(w, ix[keep] ** 2, minlength=n)
    diff = np.diff(ix, prepend=np.nan)
    pair = keep & consecutive & np.isfinite(diff)
    wd = w_all[pair]
    d_cnt = np.bincount(wd, minlength=n).astype(np.float64)
    d_ss = np.bincount(wd, diff[pair] ** 2, minlength=n)
    c60, s60, s260, dc60, dss60 = (_roll_sum(a, CONTEXT_WINDOWS) for a in (cnt, s1, s2, d_cnt, d_ss))
    f["ibi_mean"] = np.where(cnt > 0, s1 / safe_cnt, np.nan)
    f["ibi_n"] = cnt
    f["hrv_rmssd_60s"] = np.where(dc60 >= 5, np.sqrt(dss60 / np.maximum(dc60, 1)), np.nan) * 1000.0
    f["hrv_sdnn_60s"] = np.where(
        c60 >= 5, np.sqrt(np.maximum(s260 / np.maximum(c60, 1) - (s60 / np.maximum(c60, 1)) ** 2, 0)),
        np.nan) * 1000.0

    _, f["eda_mean"], _, f["eda_slope"] = _window_stats(et, ex, n)
    _, f["eda_tonic"], _, _ = _window_stats(et, tonic, n)
    _, _, f["eda_phasic_std"], _ = _window_stats(et, phasic, n)
    _, f["temp_mean"], _, _ = _window_stats(tt, tx, n)

    scr = np.bincount(_wid(scr_t).astype(np.int64), minlength=n)[:n].astype(np.float64)
    f["scr_rate_60s"] = _roll_sum(scr, CONTEXT_WINDOWS)
    temp_ctx = _nan_roll_mean(f["temp_mean"], CONTEXT_WINDOWS)
    eda_ctx = _nan_roll_mean(f["eda_tonic"], CONTEXT_WINDOWS)
    if n > 1:
        f["temp_slope_60s"] = np.gradient(temp_ctx) / WINDOW_S * 60.0
        f["eda_slope_60s"] = np.gradient(eda_ctx) / WINDOW_S * 60.0
    else:
        f["temp_slope_60s"] = np.full(n, np.nan)
        f["eda_slope_60s"] = np.full(n, np.nan)
    f["hr_mean_60s"] = _nan_roll_mean(f["hr_mean"], CONTEXT_WINDOWS)

    # Person-normalized physiological interactions & resting-floor anchors
    hr_q15, hr_q85 = _qs(f["hr_mean"], [15, 85])
    eda_q15, eda_q85 = _qs(f["eda_tonic"], [15, 85])
    bvp_q15 = _qs(f["bvp_log_rms"], [15])[0]
    hrv_q85 = _qs(f["hrv_rmssd_60s"], [85])[0]

    f["eda_phasic_ratio"] = f["eda_phasic_std"] / (np.maximum(f["eda_tonic"], 0.0) + 0.05)
    f["scr_per_hr"] = f["scr_rate_60s"] / np.maximum(f["hr_mean_60s"], 40.0)
    f["hr_above_floor"] = f["hr_mean"] - hr_q15
    f["eda_above_floor"] = f["eda_tonic"] - eda_q15
    f["bvp_rms_above_floor"] = f["bvp_log_rms"] - bvp_q15
    f["hrv_drop_from_peak"] = hrv_q85 - f["hrv_rmssd_60s"]
    f["hr_range_norm"] = f["hr_above_floor"] / (np.maximum(hr_q85 - hr_q15, 0.0) + 2.0)
    f["eda_range_norm"] = f["eda_above_floor"] / (np.maximum(eda_q85 - eda_q15, 0.0) + 0.05)
    f["eda_rel_slope"] = f["eda_slope_60s"] / (np.maximum(f["eda_tonic"], 0.0) + 0.05)
    f["hr_motion_gap"] = f["hr_above_floor"] - 20.0 * f["bvp_rms_above_floor"]

    # Stress & cooldown separation features
    scr_q15 = _qs(f["scr_rate_60s"], [15])[0]
    phasic_q15 = _qs(f["eda_phasic_std"], [15])[0]
    temp_q85 = _qs(f["temp_mean"], [85])[0]
    bvp_art_q15 = _qs(f["bvp_artifact_frac"], [15])[0]

    f["scr_above_floor"] = f["scr_rate_60s"] - scr_q15
    f["phasic_above_floor"] = f["eda_phasic_std"] - phasic_q15
    f["temp_below_ceiling"] = temp_q85 - f["temp_mean"]
    stillness = 1.0 - np.clip(f["bvp_artifact_frac"] - bvp_art_q15, 0.0, 1.0)
    f["stress_autonomic_idx"] = (
        np.maximum(f["hr_range_norm"], 0.0)
        + np.maximum(f["eda_range_norm"], 0.0)
        + 0.25 * np.maximum(f["scr_above_floor"], 0.0)
    ) * stillness
    f["still_arousal_idx"] = f["phasic_above_floor"] * stillness
    f["hr_recovery_2m"] = f["hr_mean"] - _nan_roll_mean(f["hr_mean"], 12)
    f["bvp_recovery_2m"] = f["bvp_log_rms"] - _nan_roll_mean(f["bvp_log_rms"], 12)
    f["eda_recovery_2m"] = f["eda_tonic"] - _nan_roll_mean(f["eda_tonic"], 12)
    f["hr_bvp_ratio"] = f["hr_mean"] / (f["bvp_log_rms"] + 0.5)
    f["pulse_hr_diff"] = np.abs(f["bvp_pulse_bpm"] - f["hr_mean"])

    # Short-horizon burst / onset-offset features
    hr_prev1 = np.r_[np.nan, f["hr_mean"][:-1]] if n > 1 else np.full(n, np.nan)
    hr_prev3 = np.r_[np.nan, np.nan, np.nan, f["hr_mean"][:-3]] if n > 3 else np.full(n, np.nan)
    bvp_prev1 = np.r_[np.nan, f["bvp_log_rms"][:-1]] if n > 1 else np.full(n, np.nan)
    bvp_prev3 = np.r_[np.nan, np.nan, np.nan, f["bvp_log_rms"][:-3]] if n > 3 else np.full(n, np.nan)
    ph_prev2 = np.r_[np.nan, np.nan, f["eda_phasic_std"][:-2]] if n > 2 else np.full(n, np.nan)

    f["hr_delta_10s"] = f["hr_mean"] - hr_prev1
    f["hr_delta_30s"] = f["hr_mean"] - hr_prev3
    f["bvp_rms_delta_10s"] = f["bvp_log_rms"] - bvp_prev1
    f["bvp_rms_delta_30s"] = f["bvp_log_rms"] - bvp_prev3
    f["phasic_delta_20s"] = f["eda_phasic_std"] - ph_prev2
    f["eda_slope_fast"] = f["eda_slope"]
    f["stress_burst_idx"] = (
        np.maximum(f["hr_delta_30s"], 0.0)
        * np.maximum(f["eda_phasic_std"], 0.0)
        * stillness
    )
    f["cooldown_idx"] = (
        np.maximum(f["hr_above_floor"], 0.0)
        * np.maximum(-f["hr_delta_30s"], 0.0)
        * stillness
    )

    for b in RELATIVE_BASES:
        f[f"{b}_rel"], f[f"{b}_z"], f[f"{b}_local"] = _relative(f[b])
    f["hr_temp_div"] = f["hr_mean_local"] - 10.0 * f["temp_slope_60s"]

    for b in LONG_BASES:
        for m in (2, 5):
            f[f"{b}_{m}m"] = _nan_roll_mean(f[b], 6 * m)

    for b in REC_BASES:
        for q, v in zip((10, 50, 90), _qs(f[b], [10, 50, 90])):
            f[f"rec_{b}_q{q}"] = np.full(n, v)
    f["rec_hr_range"] = f["rec_hr_mean_q90"] - f["rec_hr_mean_q10"]
    dur = float(t[-1] - offset)
    f["rec_dur"] = np.full(n, dur)
    centre = np.arange(n) * WINDOW_S + WINDOW_S / 2 - offset
    f["t_s"] = centre
    f["t_frac"] = centre / max(dur, 1.0)
    f["t_left"] = dur - centre

    for L in LAGS:
        for b in LAG_BASES:
            a = np.full(n, np.nan)
            if L > 0 and L < n:
                a[:-L] = f[b][L:]
            elif L < 0 and -L < n:
                a[-L:] = f[b][:L]
            f[f"{b}_lag{L}"] = a

    X = np.column_stack([f[k] for k in ALL_FEATURES]).astype(np.float32)
    X[~np.isfinite(X)] = np.nan
    return X, row_wid


def smooth_probs(P: np.ndarray, k: int) -> np.ndarray:
    if k <= 1 or len(P) < 2:
        return P
    norm = _same(np.ones(len(P)), k)
    return np.column_stack([_same(P[:, c], k) / norm for c in range(P.shape[1])])


def build_stage2_features(P: np.ndarray) -> np.ndarray:
    n = len(P)
    lags = (-6, -4, -2, -1, 0, 1, 2, 4, 6)
    cols = []
    for L in lags:
        block = np.full((n, 3), 1.0 / 3.0, dtype=np.float64)
        if L == 0:
            block = P
        elif L > 0 and L < n:
            block[:-L] = P[L:]
            block[-L:] = P[-1]
        elif L < 0 and -L < n:
            block[-L:] = P[:L]
            block[:-L] = P[0]
        cols.append(block)

    for k in (3, 7, 13):
        norm = _same(np.ones(n), k)[:, None]
        cols.append(np.column_stack([_same(P[:, c], k) for c in range(3)]) / norm)

    pad = np.pad(P, ((1, 1), (0, 0)), mode="edge")
    max3 = np.maximum(np.maximum(pad[:-2], pad[1:-1]), pad[2:])
    cols.append(max3)

    return np.hstack(cols).astype(np.float32)


class YourModel(ADM_Base):
    def load_model(self, onnx_file: pathlib.Path) -> None:
        so = ort.SessionOptions()
        so.intra_op_num_threads = 1
        so.inter_op_num_threads = 1
        so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        self.session = ort.InferenceSession(str(onnx_file), sess_options=so, providers=["CPUExecutionProvider"])
        self.input_name = self.session.get_inputs()[0].name
        outs = [o.name for o in self.session.get_outputs()]
        self.prob_name = next((o for o in outs if "prob" in o.lower()), outs[-1])
        meta = json.loads(self.session.get_modelmeta().custom_metadata_map["eh_config"])
        self.cols = np.array([ALL_FEATURES.index(c) for c in meta["features"]], dtype=np.int64)
        med = meta.get("medians")
        self.medians = np.asarray(med, dtype=np.float32) if med is not None else None
        self.smooth_k = int(meta.get("smooth_k", 1))
        self.log_bias = np.asarray(meta.get("log_bias", [0.0, 0.0, 0.0]), dtype=np.float64)
        self.s2_coef = np.asarray(meta["s2_coef"], dtype=np.float64) if "s2_coef" in meta else None
        self.s2_intercept = np.asarray(meta["s2_intercept"], dtype=np.float64) if "s2_intercept" in meta else None

    def predict_windows(self, df: pd.DataFrame):
        X, row_wid = compute_features(df)
        X_sub = np.ascontiguousarray(X[:, self.cols], dtype=np.float32)
        X_in = (
            np.ascontiguousarray(np.where(np.isfinite(X_sub), X_sub, self.medians), dtype=np.float32)
            if self.medians is not None
            else X_sub
        )
        P = self.session.run([self.prob_name], {self.input_name: X_in})[0]
        P = np.asarray(P, dtype=np.float64)

        if self.s2_coef is not None:
            S2_X = build_stage2_features(P).astype(np.float64)
            logits = S2_X @ self.s2_coef.T + self.s2_intercept + self.log_bias
            return logits.argmax(axis=1), row_wid

        P = smooth_probs(P, self.smooth_k)
        score = np.log(np.maximum(P, 1e-9)) + self.log_bias
        return score.argmax(axis=1), row_wid

    def run(self, input: pd.DataFrame) -> pd.DataFrame:
        n_rows = len(input)
        if n_rows == 0:
            return pd.DataFrame({"Activity": pd.Series(dtype=object)}, index=input.index)
        data = input[INPUT_COLS]
        if not isinstance(data.index, pd.DatetimeIndex):
            data = data.set_axis(pd.date_range("2000-01-01", periods=n_rows, freq="15625us"))
        labels = np.full(n_rows, "Rest", dtype=object)
        with warnings.catch_warnings(), np.errstate(all="ignore"):
            warnings.simplefilter("ignore")
            for s, e in _input_segments(data.index):
                try:
                    win_pred, row_wid = self.predict_windows(data.iloc[s:e])
                    labels[s:e] = CLASSES[win_pred[np.clip(row_wid, 0, len(win_pred) - 1)]]
                except Exception:
                    pass
        return pd.DataFrame({"Activity": pd.Series(labels, index=input.index, dtype=object, copy=False)})


MAX_JUMP_NS = 300 * 10**9


def _input_segments(index: pd.DatetimeIndex):
    ns = index.asi8
    d = np.diff(ns)
    breaks = np.flatnonzero((d < 0) | (d > MAX_JUMP_NS)) + 1
    return zip(np.r_[0, breaks], np.r_[breaks, len(ns)])


def get_model() -> ADM_Base:
    model = YourModel()
    model.load_model(pathlib.Path(__file__).with_suffix(".onnx"))
    return model