import pathlib
import numpy as np
import pandas as pd
import onnxruntime as ort
from adm_base_class import ADM_Base

REQUIRED_COLS = ["BVP", "EDA", "HR", "IBI_dt", "IBI_duration", "Temperature"]
BLOCK_SIZE = 640  # 10-second window at 64 Hz
CLASSES = np.array(["Rest", "Activity", "Stress"], dtype=object)


def extract_v2_features(df_input: pd.DataFrame) -> tuple[np.ndarray, int]:
    """
    Extracts 36 fast vectorized features per 640-row (10s) block:
    - 6 raw means + 6 raw stds
    - 6 subject-calibrated delta-means (relative to first 60s baseline)
    - 6 intra-block slopes (second half mean minus first half mean)
    - 6 lagged delta-means (t-1 block) + 6 lead delta-means (t+1 block)
    """
    n_rows = len(df_input)
    arr = df_input[REQUIRED_COLS].ffill().bfill().fillna(0.0).to_numpy(dtype=np.float32)
    arr = np.clip(arr, -1e4, 1e4)

    n_cols = arr.shape[1]
    n_blocks = max(1, int(np.ceil(n_rows / BLOCK_SIZE)))
    pad_len = (n_blocks * BLOCK_SIZE) - n_rows
    if pad_len > 0:
        arr = np.pad(arr, ((0, pad_len), (0, 0)), mode="edge")

    blocks = arr.reshape(n_blocks, BLOCK_SIZE, n_cols)

    # 1. Raw block statistics (12 features)
    means = blocks.mean(axis=1)
    stds = blocks.std(axis=1)

    # 2. Per-recording baseline calibration (first 6 blocks = 60s Baseline Rest)
    base_len = min(6, n_blocks)
    baseline_mean = np.median(means[:base_len], axis=0, keepdims=True)
    baseline_std = np.std(means, axis=0, keepdims=True) + 1e-5
    delta_means = (means - baseline_mean) / baseline_std  # Normalized Z-shift (6 features)

    # 3. Intra-block slope: 2nd half (5s) minus 1st half (5s) (6 features)
    half = BLOCK_SIZE // 2
    slopes = blocks[:, half:, :].mean(axis=1) - blocks[:, :half, :].mean(axis=1)

    # 4. Temporal context: previous block (t-1) and next block (t+1) delta_means (12 features)
    prev_delta = np.vstack([delta_means[:1], delta_means[:-1]])
    next_delta = np.vstack([delta_means[1:], delta_means[-1:]])

    features = np.hstack([means, stds, delta_means, slopes, prev_delta, next_delta]).astype(np.float32)
    return features, n_rows


class YourModel(ADM_Base):
    def load_model(self, onnx_file: pathlib.Path) -> None:
        sess_options = ort.SessionOptions()
        sess_options.intra_op_num_threads = 1
        sess_options.inter_op_num_threads = 1
        self.session = ort.InferenceSession(
            onnx_file,
            sess_options=sess_options,
            providers=["CPUExecutionProvider"],
        )
        self.input_name = self.session.get_inputs()[0].name

    def run(self, input: pd.DataFrame) -> pd.DataFrame:
        if len(input) == 0:
            return pd.DataFrame({"Activity": pd.Series(dtype=str)}, index=input.index)

        features, n_rows = extract_v2_features(input)

        # Run ONNX inference -> returns integer indices (0, 1, 2)
        pred_ids = self.session.run(None, {self.input_name: features})[0].astype(np.int64)
        pred_ids = np.clip(pred_ids, 0, 2)

        # Temporal median/mode filter across 3 blocks (eliminates isolated 10s glitches)
        if len(pred_ids) >= 3:
            smoothed = pred_ids.copy()
            for i in range(1, len(pred_ids) - 1):
                if pred_ids[i - 1] == pred_ids[i + 1] and pred_ids[i] != pred_ids[i - 1]:
                    smoothed[i] = pred_ids[i - 1]
            pred_ids = smoothed

        block_labels = CLASSES[pred_ids]
        row_preds = np.repeat(block_labels, BLOCK_SIZE)[:n_rows]
        return pd.DataFrame({"Activity": row_preds}, index=input.index)


def get_model() -> ADM_Base:
    model = YourModel()
    model.load_model(pathlib.Path(__file__).with_suffix(".onnx"))
    return model